#include <iostream>
using namespace std;

/*
Tree represents the nodes connected by edges. We will discuss binary tree or binary search
tree specifically.

Binary Tree is a special datastructure used for data storage purposes. A binary tree has a
special condition that each node can have a maximum of two children. A binary tree has
the benefits of both an ordered array and a linked list as search is as quick as in a sorted
array and insertion or deletion operation are as fast as in linked list.

ImportantTerms
Following are the important terms with respect to tree.
 Path − Path refers to the sequence of nodes along the edges of a tree.

 Root – The node at the top of the tree is called root. There is only one root per
tree and one path from the root node to any node.

 Parent − Any node except the root node has one edge upward to a node called
parent.

 Child – The node below a given node connected by its edge downward is called its
child node.

 Leaf – The node which does not have any child node is called the leaf node.

 Subtree − Subtree represents the descendants of a node.

 Visiting − Visiting refers to checking the value of a node when control is on the
node.

 Traversing − Traversing means passing through nodes in a specific order.

 Levels − Level of a node represents the generation of a node. If the root node is
at level 0, then its next child node is at level 1, its grandchild is at level 2, and so
on.

 Keys − Key represents a value of a node based on which a search operation is to
be carried out for a node.

*/

/*
TreeNode:
The code to write a tree node would be similar to what is given below.
 It has a data part and references to its left and right child nodes.
*/
class node
{

public:
    int data;
    node *left;  // points to left child
    node *right; // points to right child

    // constructor
    node(int value)
    {
        data = value;
        left = NULL;
        right = NULL;
    }
};

main()

{

    node *root = new node(1); // root node for whole binary tree
    root->left = new node(2);
    root->right = new node(3);
    /*
                1
              /  \
            2    3
    */

    root->left->left = new node(4);
    root->left->right = new node(5);
    /*
                 1
               /  \
             2    3
            / \
          4    5
     */

    root->right->right = new node(7);
    root->right->left = new node(6);
    /*
                 1
               /  \
            2       3
         / \       / \
       4    5    6    7
     */
}