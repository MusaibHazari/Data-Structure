deleteAtHead(head);
    display(head);
    deleteAtHead(head);
    display(head);